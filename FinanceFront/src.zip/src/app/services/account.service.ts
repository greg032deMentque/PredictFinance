import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface CurrentUserProfile {
  Email: string;
  FirstName: string;
  LastName: string;
  PhoneNumber: string;
}

export interface UpdateCurrentUserProfileRequest {
  FirstName: string;
  LastName: string;
  PhoneNumber: string;
}

export interface ChangePasswordRequest {
  CurrentPassword: string;
  NewPassword: string;
}

export interface ForgotPasswordRequest {
  Email: string;
}

export interface ResetPasswordRequest {
  Email: string;
  Token: string;
  Password: string;
  ConfirmPassword: string;
}

@Injectable({ providedIn: 'root' })
export class AccountService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = `${environment.apiUrl}Account/`;

  getProfile(): Observable<CurrentUserProfile> {
    return this.http.get<CurrentUserProfile>(`${this.baseUrl}Profile`);
  }

  updateProfile(request: UpdateCurrentUserProfileRequest): Observable<CurrentUserProfile> {
    return this.http.put<CurrentUserProfile>(`${this.baseUrl}Profile`, request);
  }

  changePassword(request: ChangePasswordRequest): Observable<void> {
    return this.http.post<void>(`${this.baseUrl}ChangePassword`, request);
  }

  forgotPassword(request: ForgotPasswordRequest): Observable<void> {
    return this.http.post<void>(`${this.baseUrl}ForgotPassword`, request);
  }

  resetPassword(request: ResetPasswordRequest): Observable<void> {
    return this.http.post<void>(`${this.baseUrl}ResetPassword`, request);
  }
}
