import { Component, inject, signal } from '@angular/core';
import { NavigationEnd, Router, RouterOutlet } from '@angular/router';
import { filter } from 'rxjs';
import { AllModule } from '../../../module/allModule.module';
import { AppRoutes } from '../../../Routes/app.routes.constants';
import { AuthService } from '../../../services/AuthService.service';
import { MenuLink, MenuService } from '../../../services';

@Component({
  selector: 'app-client-layout',
  standalone: true,
  imports: [RouterOutlet, AllModule],
  templateUrl: './client-layout-component.html',
  styleUrls: ['./client-layout-component.scss']
})
export class ClientLayoutComponent {
  private readonly menuService = inject(MenuService);
  private readonly authService = inject(AuthService);
  readonly menuBlocks = this.menuService.getClientMenu();
  readonly openedLink = signal<string | null>(null);
  readonly pageTitle = signal('Accueil user');
  private readonly router = inject(Router);

  constructor() {
    this.router.events.pipe(filter((event) => event instanceof NavigationEnd)).subscribe(() => {
      const url = this.router.url;
      if (url.includes(`/${AppRoutes.Notifications}`)) {
        this.pageTitle.set('Notifications');
        return;
      }

      if (url.includes(`/${AppRoutes.Watchlist}`)) {
        this.pageTitle.set('Watchlist');
        return;
      }

      if (url.includes(`/${AppRoutes.Portfolio}`)) {
        this.pageTitle.set('Portfolio');
        return;
      }

      if (url.includes(`/${AppRoutes.Analysis}`)) {
        this.pageTitle.set('Analyse');
        return;
      }

      if (url.includes(`/${AppRoutes.History}`)) {
        this.pageTitle.set('Historique');
        return;
      }

      if (url.includes(`/${AppRoutes.Simulation}`)) {
        this.pageTitle.set('Simulation');
        return;
      }

      if (url.includes(`/${AppRoutes.Account}`)) {
        this.pageTitle.set('Compte');
        return;
      }

      this.pageTitle.set('Accueil user');
    });
  }

  toggleLink(linkLabel: string) {
    this.openedLink.update((v) => (v === linkLabel ? null : linkLabel));
  }

  isLinkOpen(linkLabel: string) {
    return this.openedLink() === linkLabel;
  }

  onLinkClick(evt: MouseEvent, link: MenuLink) {
    if (!link.actions?.length) {
      return;
    }

    evt.preventDefault();
    this.toggleLink(link.label);
  }

  logout() {
    this.authService.logout();
  }
}
