import { CommonModule, DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { finalize } from 'rxjs';
import { environment } from '../../../../environments/environment';

interface NotificationItem {
  NotificationId: string;
  Category: number | string;
  Status: number | string;
  Title: string;
  Summary: string;
  CreatedAtUtc: string;
  TargetScreen?: number | string | null;
  TargetEntityId?: string | null;
  ReadAtUtc?: string | null;
}

@Component({
  selector: 'app-notifications',
  standalone: true,
  imports: [CommonModule, FormsModule, DatePipe],
  templateUrl: './notifications.component.html',
  styleUrl: './notifications.component.scss'
})
export class NotificationsComponent implements OnInit {
  private readonly http = inject(HttpClient);

  notifications: NotificationItem[] = [];
  loading = false;
  selectedStatus = 'all';
  error: string | null = null;

  ngOnInit(): void {
    this.loadNotifications();
  }

  loadNotifications(): void {
    this.loading = true;
    this.error = null;

    const queryParts: string[] = ['take=50'];

    if (this.selectedStatus === 'unread') {
      queryParts.push('status=0');
    }

    if (this.selectedStatus === 'read') {
      queryParts.push('status=1');
    }

    this.http
      .get<NotificationItem[]>(`${environment.apiUrl}Notifications/GetList?${queryParts.join('&')}`)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe({
        next: (payload) => {
          this.notifications = payload ?? [];
        },
        error: () => {
          this.notifications = [];
          this.error = 'Impossible de charger les notifications.';
        }
      });
  }

  markAsRead(notification: NotificationItem): void {
    if (!notification.NotificationId || this.isRead(notification)) {
      return;
    }

    this.http
      .post<NotificationItem>(`${environment.apiUrl}Notifications/MarkAsRead`, {
        NotificationId: notification.NotificationId
      })
      .subscribe({
        next: (updated) => {
          this.notifications = this.notifications.map((item) =>
            item.NotificationId === updated.NotificationId ? updated : item
          );
        }
      });
  }

  isRead(notification: NotificationItem): boolean {
    return notification.ReadAtUtc !== null && notification.ReadAtUtc !== undefined && notification.ReadAtUtc !== '';
  }

  get unreadCount(): number {
    return this.notifications.filter((item) => !this.isRead(item)).length;
  }

  get filteredNotifications(): NotificationItem[] {
    if (this.selectedStatus === 'all') {
      return this.notifications;
    }

    if (this.selectedStatus === 'read') {
      return this.notifications.filter((item) => this.isRead(item));
    }

    return this.notifications.filter((item) => !this.isRead(item));
  }
}
