import { CommonModule, DatePipe } from '@angular/common';
import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { ClientHistoryFeed } from '../../../../Models/client-finance-models/client-finance-models';
import { UserPaths } from '../../../../Routes/app.routes.constants';
import { ClientFinanceService } from '../../../../services/client-finance.service';
import { ToastService } from '../../../../services/toastr.service';

@Component({ selector: 'app-history-page', standalone: true, imports: [CommonModule, RouterLink, DatePipe], templateUrl: './history-page.component.html', styleUrl: './history-page.component.scss' })
export class HistoryPageComponent {
  private readonly clientFinanceService = inject(ClientFinanceService);
  private readonly toastService = inject(ToastService);
  readonly userPaths = UserPaths;
  history: ClientHistoryFeed = { Items: [], ReturnedCount: 0 };
  loading = false;
  constructor() { this.loadHistory(); }
  private loadHistory(): void {
    this.loading = true;
    this.clientFinanceService.getHistory(30).pipe(finalize(() => (this.loading = false))).subscribe({ next: (payload) => (this.history = payload), error: () => { this.history = { Items: [], ReturnedCount: 0 }; this.toastService.error('Chargement de l’historique impossible.'); } });
  }
}
