import { CommonModule, CurrencyPipe, DatePipe, DecimalPipe } from '@angular/common';
import { Component, inject } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { ClientInstrumentDetail, ClientInstrumentHistory } from '../../../../Models/client-finance-models/client-finance-models';
import { UserPaths } from '../../../../Routes/app.routes.constants';
import { ClientFinanceService } from '../../../../services/client-finance.service';
import { ToastService } from '../../../../services/toastr.service';

@Component({ selector: 'app-instrument-detail-page', standalone: true, imports: [CommonModule, RouterLink, CurrencyPipe, DecimalPipe, DatePipe], templateUrl: './instrument-detail-page.component.html', styleUrl: './instrument-detail-page.component.scss' })
export class InstrumentDetailPageComponent {
  private readonly clientFinanceService = inject(ClientFinanceService);
  private readonly toastService = inject(ToastService);
  private readonly route = inject(ActivatedRoute);
  readonly userPaths = UserPaths;
  detail: ClientInstrumentDetail | null = null;
  history: ClientInstrumentHistory | null = null;
  loading = false;
  constructor() { const symbol = this.route.snapshot.paramMap.get('symbol'); if (symbol) this.loadInstrument(symbol); }
  private loadInstrument(symbol: string): void {
    this.loading = true;
    this.clientFinanceService.getInstrumentDetail(symbol).pipe(finalize(() => (this.loading = false))).subscribe({ next: (payload) => (this.detail = payload), error: () => { this.detail = null; this.toastService.error('Lecture instrument impossible.'); } });
    this.clientFinanceService.getInstrumentHistory(symbol, 10).subscribe({ next: (payload) => (this.history = payload), error: () => { this.history = null; } });
  }
}
