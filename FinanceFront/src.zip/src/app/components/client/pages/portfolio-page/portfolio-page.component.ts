import { CommonModule, CurrencyPipe, DatePipe, DecimalPipe } from '@angular/common';
import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { ClientPortfolio, ClientTransactionCreateRequest, ClientTransactionItem } from '../../../../Models/client-finance-models/client-finance-models';
import { UserPaths } from '../../../../Routes/app.routes.constants';
import { ClientFinanceService } from '../../../../services/client-finance.service';
import { ToastService } from '../../../../services/toastr.service';
import { FinanceTransactionFormComponent } from '../../user-finance/finance-transaction-form/finance-transaction-form.component';

@Component({ selector: 'app-portfolio-page', standalone: true, imports: [CommonModule, RouterLink, CurrencyPipe, DecimalPipe, DatePipe, FinanceTransactionFormComponent], templateUrl: './portfolio-page.component.html', styleUrl: './portfolio-page.component.scss' })
export class PortfolioPageComponent {
  private readonly clientFinanceService = inject(ClientFinanceService);
  private readonly toastService = inject(ToastService);
  readonly userPaths = UserPaths;
  portfolio: ClientPortfolio = { Positions: [], TotalInvestedAmount: 0, TotalOutstandingAmount: 0, OpenPositionCount: 0 };
  transactions: ClientTransactionItem[] = [];
  selectedSymbol = '';
  loading = false;
  transactionLoading = false;
  constructor() { this.loadPortfolio(); this.loadTransactions(); }
  onOpenTransaction(symbol: string): void { this.selectedSymbol = symbol; }
  onSaveTransaction(request: ClientTransactionCreateRequest): void {
    this.transactionLoading = true;
    this.clientFinanceService.registerTransaction(request).pipe(finalize(() => (this.transactionLoading = false))).subscribe({ next: (transaction) => { this.transactions = [transaction, ...this.transactions].slice(0, 50); this.toastService.success('Transaction enregistrée.'); this.loadPortfolio(); }, error: () => this.toastService.error('Enregistrement de transaction impossible.') });
  }
  deleteTransaction(transactionId: string): void {
    if (!transactionId || this.transactionLoading) return;
    this.transactionLoading = true;
    this.clientFinanceService.deleteTransaction(transactionId).pipe(finalize(() => (this.transactionLoading = false))).subscribe({ next: () => { this.transactions = this.transactions.filter((item) => item.Id !== transactionId); this.toastService.success('Transaction supprimée.'); this.loadPortfolio(); }, error: () => this.toastService.error('Suppression de transaction impossible.') });
  }
  private loadPortfolio(): void {
    this.loading = true;
    this.clientFinanceService.getPortfolio().pipe(finalize(() => (this.loading = false))).subscribe({ next: (payload) => (this.portfolio = payload), error: () => { this.portfolio = { Positions: [], TotalInvestedAmount: 0, TotalOutstandingAmount: 0, OpenPositionCount: 0 }; this.toastService.error('Chargement du portfolio impossible.'); } });
  }
  private loadTransactions(): void { this.clientFinanceService.getTransactions(25).subscribe({ next: (items) => (this.transactions = items), error: () => { this.transactions = []; } }); }
}
