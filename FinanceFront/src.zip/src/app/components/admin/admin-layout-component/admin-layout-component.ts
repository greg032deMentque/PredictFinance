import { Component, inject, signal } from '@angular/core';
import { NavigationEnd, Router, RouterOutlet } from '@angular/router';
import { filter } from 'rxjs';
import { AllModule } from '../../../module/allModule.module';
import { AppRoutes } from '../../../Routes/app.routes.constants';
import { AuthService } from '../../../services/AuthService.service';
import { MenuService, MenuLink } from '../../../services';

@Component({
  selector: 'app-admin-layout',
  standalone: true,
  imports: [RouterOutlet, AllModule],
  templateUrl: './admin-layout-component.html',
  styleUrls: ['./admin-layout-component.scss']
})
export class AdminLayoutComponent {
  private readonly menuService = inject(MenuService);
  private readonly authService = inject(AuthService);
  readonly menuBlocks = this.menuService.getAdminMenu();
  readonly openedLink = signal<string | null>(null);
  readonly pageTitle = signal('Overview');
  private readonly router = inject(Router);

  constructor() {
    this.router.events.pipe(filter((event) => event instanceof NavigationEnd)).subscribe(() => {
      const url = this.router.url;

      if (url.includes(`/${AppRoutes.InstrumentRegistry}`)) {
        this.pageTitle.set('Instrument registry');
        return;
      }

      if (url.includes(`/${AppRoutes.PeaRegistry}`)) {
        this.pageTitle.set('PEA registry');
        return;
      }

      if (url.includes(`/${AppRoutes.ScoringPolicy}`)) {
        this.pageTitle.set('Scoring policy');
        return;
      }

      if (url.includes(`/${AppRoutes.ParameterDictionary}`)) {
        this.pageTitle.set('Parameter dictionary');
        return;
      }

      if (url.includes(`/${AppRoutes.WordingVersions}`)) {
        this.pageTitle.set('Wording versions');
        return;
      }

      if (url.includes(`/${AppRoutes.SnapshotAudit}`)) {
        this.pageTitle.set('Snapshot audit');
        return;
      }

      if (url.includes(`/${AppRoutes.DataQuality}`)) {
        this.pageTitle.set('Data quality');
        return;
      }

      if (url.includes(`/${AppRoutes.Users}`)) {
        this.pageTitle.set('Users');
        return;
      }


      this.pageTitle.set('Overview');
    });
  }

  toggleLink(linkLabel: string) {
    this.openedLink.update((v) => (v === linkLabel ? null : linkLabel));
  }

  isLinkOpen(linkLabel: string) {
    return this.openedLink() === linkLabel;
  }

  onLinkClick(evt: MouseEvent, link: MenuLink) {
    if (!link.actions?.length) {
      return;
    }

    evt.preventDefault();
    this.toggleLink(link.label);
  }

  logout() {
    this.authService.logout();
  }
}
