import { AppRoutes } from '../Routes/app.routes.constants';
import { MenuService } from '../services';

describe('MenuService', () => {
  let service: MenuService;

  beforeEach(() => {
    service = new MenuService();
  });

  it('should expose the new separated client navigation entries', () => {
    const labels = service.getClientMenu().flatMap((block) => block.links.map((link) => link.label));

    expect(labels).toEqual([
      'Accueil user',
      'Watchlist',
      'Portfolio',
      'Analyse',
      'Historique',
      'Simulation',
      'Notifications',
      'Compte'
    ]);
  });

  it('should not expose the legacy finance entry in the client menu', () => {
    const clientLinks = service.getClientMenu().flatMap((block) => block.links);
    const legacyLink = clientLinks.find((link) => link.commands.join('/') === `//${AppRoutes.ClientRoot}/${AppRoutes.Finance}`);

    expect(legacyLink).toBeUndefined();
  });

  it('should keep watchlist and portfolio as distinct client destinations', () => {
    const clientLinks = service.getClientMenu().flatMap((block) => block.links);
    const watchlistLink = clientLinks.find((link) => link.label === 'Watchlist');
    const portfolioLink = clientLinks.find((link) => link.label === 'Portfolio');

    expect(watchlistLink?.commands).toEqual(['/', AppRoutes.ClientRoot, AppRoutes.Watchlist]);
    expect(portfolioLink?.commands).toEqual(['/', AppRoutes.ClientRoot, AppRoutes.Portfolio]);
  });

  it('should keep the governance links available in the admin menu', () => {
    const adminLabels = service.getAdminMenu().flatMap((block) => block.links.map((link) => link.label));

    expect(adminLabels).toContain('Instrument registry');
    expect(adminLabels).toContain('PEA registry');
    expect(adminLabels).toContain('Scoring policy');
    expect(adminLabels).toContain('Parameter dictionary');
    expect(adminLabels).toContain('Wording versions');
    expect(adminLabels).toContain('Snapshot audit');
    expect(adminLabels).toContain('Data quality');
  });
});
