import { of, throwError } from 'rxjs';
import { AuthService } from '../services/AuthService.service';

describe('AuthService', () => {
  const createJwt = (payload: Record<string, unknown>) => {
    const encodedPayload = btoa(JSON.stringify(payload));
    return `header.${encodedPayload}.signature`;
  };

  const createSut = (overrides?: {
    token?: string;
    refreshToken?: string;
    postResult?: unknown;
    postError?: unknown;
  }) => {
    const storageService = {
      GetToken: jasmine.createSpy().and.returnValue(overrides?.token ?? 'access-token'),
      GetRefreshToken: jasmine.createSpy().and.returnValue(overrides?.refreshToken ?? 'refresh-token'),
      SetToken: jasmine.createSpy(),
      SetRefreshToken: jasmine.createSpy(),
      RemoveToken: jasmine.createSpy(),
      RemoveRefreshToken: jasmine.createSpy()
    };

    const http = {
      post: jasmine.createSpy().and.callFake(() => {
        if (overrides && 'postError' in overrides) {
          return throwError(() => overrides.postError);
        }

        return of(overrides?.postResult ?? {});
      })
    };

    const router = {
      navigate: jasmine.createSpy().and.returnValue(Promise.resolve(true))
    };

    const authStore = {
      clear: jasmine.createSpy()
    };

    return {
      storageService,
      http,
      router,
      authStore,
      service: new AuthService(http as never, storageService as never, router as never, authStore as never)
    };
  };

  it('logout should post logout, clear tokens and navigate to login', async () => {
    const { service, http, storageService, router, authStore } = createSut();

    service.logout();
    await Promise.resolve();

    expect(http.post).toHaveBeenCalledOnceWith(jasmine.stringMatching(/Account\/Logout$/), {
      Token: 'access-token',
      RefreshToken: 'refresh-token'
    });
    expect(storageService.RemoveToken).toHaveBeenCalledTimes(1);
    expect(storageService.RemoveRefreshToken).toHaveBeenCalledTimes(1);
    expect(authStore.clear).toHaveBeenCalledOnceWith(false);
    expect(router.navigate).toHaveBeenCalledOnceWith(['login']);
  });

  it('logout should still clear local session when logout endpoint fails', async () => {
    const { service, storageService, router, authStore } = createSut({ postError: new Error('network') });

    service.logout();
    await Promise.resolve();

    expect(storageService.RemoveToken).toHaveBeenCalledTimes(1);
    expect(storageService.RemoveRefreshToken).toHaveBeenCalledTimes(1);
    expect(authStore.clear).toHaveBeenCalledOnceWith(false);
    expect(router.navigate).toHaveBeenCalledOnceWith(['login']);
  });

  it('ensureValidAccessToken should return the current token when it is not expired', (done) => {
    const token = createJwt({ exp: Math.floor(Date.now() / 1000) + 3600 });
    const { service, http } = createSut({ token });

    service.ensureValidAccessToken().subscribe((result) => {
      expect(result).toBe(token);
      expect(http.post).not.toHaveBeenCalled();
      done();
    });
  });

  it('ensureValidAccessToken should refresh and return the new token when the token is expired', (done) => {
    const expiredToken = createJwt({ exp: Math.floor(Date.now() / 1000) - 10 });
    const refreshedToken = createJwt({ exp: Math.floor(Date.now() / 1000) + 7200, role: 'admin' });
    const { service, http, storageService } = createSut({
      token: expiredToken,
      refreshToken: 'valid-refresh-token',
      postResult: { Token: refreshedToken, RefreshToken: 'next-refresh-token' }
    });

    service.ensureValidAccessToken().subscribe((result) => {
      expect(result).toBe(refreshedToken);
      expect(http.post).toHaveBeenCalledOnceWith(jasmine.stringMatching(/Account\/Refresh$/), {
        Token: expiredToken,
        RefreshToken: 'valid-refresh-token'
      });
      expect(storageService.SetToken).toHaveBeenCalledOnceWith(refreshedToken);
      expect(storageService.SetRefreshToken).toHaveBeenCalledOnceWith('next-refresh-token');
      done();
    });
  });

  it('getUserRolesFromToken should normalize a single role string', () => {
    const token = createJwt({ role: 'Admin' });
    const { service } = createSut();

    expect(service.getUserRolesFromToken(token)).toEqual(['Admin']);
    expect(service.isAdmin(token)).toBeTrue();
  });

  it('getUserRolesFromToken should normalize a role array and detect super admin', () => {
    const token = createJwt({ roles: ['reader', 'SuperAdmin'] });
    const { service } = createSut();

    expect(service.getUserRolesFromToken(token)).toEqual(['reader', 'SuperAdmin']);
    expect(service.isSuperAdmin(token)).toBeTrue();
    expect(service.isAdmin(token)).toBeTrue();
  });
});
