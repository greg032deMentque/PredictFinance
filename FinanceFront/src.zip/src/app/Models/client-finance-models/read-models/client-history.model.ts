export interface ClientHistoryItem {
  AnalysisId: string; SnapshotId: string;
  Instrument: { InstrumentId: string; Symbol: string; DisplayName: string; AssetType: string; Exchange: string; Currency: string; CountryCode: string | null };
  TimestampUtc: string; OutcomeDisplayLabel: string; PrimaryPatternLabel: string | null; RecommendationSummary: string; SupportAvailabilitySummary: string; PeaSummary: string; AnalysisEngineVersion: string; RecommendationPolicyVersion: string | null; ExplanationPolicyVersion: string | null; DetailUrl: string; HistoryUrl: string; ComparisonUrl: string;
}
export interface ClientHistoryFeed { Items: ClientHistoryItem[]; ReturnedCount: number; }
export interface ClientInstrumentHistoryItem { AnalysisId: string; SnapshotId: string; TimestampUtc: string; OutcomeDisplayLabel: string; PrimaryPatternLabel: string | null; RecommendationSummary: string; SupportAvailabilitySummary: string; PeaSummary: string; AnalysisEngineVersion: string; RecommendationPolicyVersion: string | null; ExplanationPolicyVersion: string | null; DetailUrl: string; ComparisonUrl: string; }
export interface ClientInstrumentHistory {
  Instrument: { InstrumentId: string; Symbol: string; DisplayName: string; AssetType: string; Exchange: string; Currency: string; CountryCode: string | null };
  Symbol: string; Items: ClientInstrumentHistoryItem[]; ReturnedCount: number;
}
