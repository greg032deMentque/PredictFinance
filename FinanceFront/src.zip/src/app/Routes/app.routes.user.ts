import { Routes } from '@angular/router';
import { ClientDashboardComponent } from '../components/client/client-dashboard/client-dashboard';
import { NotificationsComponent } from '../components/client/notifications/notifications.component';
import { AuthGuard, ClientGuard } from '../guard';
import { AppRoutes, buildRoute } from './app.routes.constants';
import { ClientLayoutComponent } from '../components/client/client-layout-component/client-layout-component';
import { ClientAccountPageComponent } from '../components/client/account/shell/client-account-page.component';
import { AccountProfileComponent } from '../components/client/account/profile/account-profile.component';
import { AccountSecurityComponent } from '../components/client/account/security/account-security.component';
import { WatchlistPageComponent } from '../components/client/pages/watchlist-page/watchlist-page.component';
import { PortfolioPageComponent } from '../components/client/pages/portfolio-page/portfolio-page.component';
import { AnalysisEntryPageComponent } from '../components/client/pages/analysis-entry-page/analysis-entry-page.component';
import { AnalysisDetailPageComponent } from '../components/client/pages/analysis-detail-page/analysis-detail-page.component';
import { HistoryPageComponent } from '../components/client/pages/history-page/history-page.component';
import { SimulationPageComponent } from '../components/client/pages/simulation-page/simulation-page.component';
import { InstrumentDetailPageComponent } from '../components/client/pages/instrument-detail-page/instrument-detail-page.component';

export const USER_ROUTES: Routes = [
  {
    path: AppRoutes.ClientRoot,
    component: ClientLayoutComponent,
    canActivate: [AuthGuard, ClientGuard],
    children: [
      { path: '', pathMatch: 'full', redirectTo: AppRoutes.Dashboard },
      { path: AppRoutes.Dashboard, component: ClientDashboardComponent },
      { path: AppRoutes.Finance, pathMatch: 'full', redirectTo: AppRoutes.Watchlist },
      { path: AppRoutes.Notifications, component: NotificationsComponent },
      { path: AppRoutes.Watchlist, component: WatchlistPageComponent },
      { path: AppRoutes.Portfolio, component: PortfolioPageComponent },
      { path: AppRoutes.Analysis, component: AnalysisEntryPageComponent },
      { path: buildRoute(AppRoutes.Analysis, ':analysisId'), component: AnalysisDetailPageComponent },
      { path: AppRoutes.History, component: HistoryPageComponent },
      { path: AppRoutes.Simulation, component: SimulationPageComponent },
      { path: buildRoute(AppRoutes.Instruments, ':symbol'), component: InstrumentDetailPageComponent },
      {
        path: AppRoutes.Account,
        component: ClientAccountPageComponent,
        children: [
          { path: '', pathMatch: 'full', redirectTo: AppRoutes.Profile },
          { path: AppRoutes.Profile, component: AccountProfileComponent },
          { path: AppRoutes.Security, component: AccountSecurityComponent }
        ]
      }
    ]
  }
];

