import { Routes } from '@angular/router';
import { AdminDashboardComponent } from '../components/admin/admin-dashboard/admin-dashboard.component';
import { AdminUserFormComponent } from '../components/admin/user/form/admin-user-form.component';
import { AdminUsersListComponent } from '../components/admin/user/list/admin-users-list.component';
import { AdminGuard, AuthGuard } from '../guard';
import { AppRoutes } from './app.routes.constants';
import { AdminLayoutComponent } from '../components/admin/admin-layout-component/admin-layout-component';
import { AdminInstrumentRegistryComponent } from '../components/admin/governance/admin-instrument-registry/admin-instrument-registry.component';
import { AdminPeaRegistryComponent } from '../components/admin/governance/admin-pea-registry/admin-pea-registry.component';
import { AdminScoringPolicyComponent } from '../components/admin/governance/admin-scoring-policy/admin-scoring-policy.component';
import { AdminParameterDictionaryComponent } from '../components/admin/governance/admin-parameter-dictionary/admin-parameter-dictionary.component';
import { AdminWordingVersionsComponent } from '../components/admin/governance/admin-wording-versions/admin-wording-versions.component';
import { AdminSnapshotAuditComponent } from '../components/admin/governance/admin-snapshot-audit/admin-snapshot-audit.component';
import { AdminDataQualityComponent } from '../components/admin/governance/admin-data-quality/admin-data-quality.component';
import { AdminParameterDictionaryDetailComponent } from '../components/admin/governance/admin-parameter-dictionary-detail/admin-parameter-dictionary-detail.component';
import { AdminWordingVersionDetailComponent } from '../components/admin/governance/admin-wording-version-detail/admin-wording-version-detail.component';
import { AdminSnapshotAuditDetailComponent } from '../components/admin/governance/admin-snapshot-audit-detail/admin-snapshot-audit-detail.component';
import { AdminSnapshotAuditCompareComponent } from '../components/admin/governance/admin-snapshot-audit-compare/admin-snapshot-audit-compare.component';

export const ADMIN_ROUTES: Routes = [
  {
    path: AppRoutes.AdminRoot,
    component: AdminLayoutComponent,
    canActivate: [AuthGuard, AdminGuard],
    children: [
      { path: '', pathMatch: 'full', redirectTo: AppRoutes.Dashboard },
      { path: AppRoutes.Dashboard, component: AdminDashboardComponent },
      { path: AppRoutes.Users, component: AdminUsersListComponent },
      { path: `${AppRoutes.Users}/${AppRoutes.Add}`, component: AdminUserFormComponent },
      { path: `${AppRoutes.Users}/${AppRoutes.Edit}/:id`, component: AdminUserFormComponent },
      { path: AppRoutes.InstrumentRegistry, component: AdminInstrumentRegistryComponent },
      { path: AppRoutes.PeaRegistry, component: AdminPeaRegistryComponent },
      { path: AppRoutes.ScoringPolicy, component: AdminScoringPolicyComponent },
      { path: AppRoutes.ParameterDictionary, component: AdminParameterDictionaryComponent },
      { path: `${AppRoutes.ParameterDictionary}/${AppRoutes.Detail}/:parameterId`, component: AdminParameterDictionaryDetailComponent },
      { path: AppRoutes.WordingVersions, component: AdminWordingVersionsComponent },
      { path: `${AppRoutes.WordingVersions}/${AppRoutes.Detail}/:wordingVersionId`, component: AdminWordingVersionDetailComponent },
      { path: AppRoutes.SnapshotAudit, component: AdminSnapshotAuditComponent },
      { path: `${AppRoutes.SnapshotAudit}/${AppRoutes.Detail}/:analysisRunId`, component: AdminSnapshotAuditDetailComponent },
      { path: `${AppRoutes.SnapshotAudit}/${AppRoutes.Compare}`, component: AdminSnapshotAuditCompareComponent },
      { path: AppRoutes.DataQuality, component: AdminDataQualityComponent }
    ]
  }
];
