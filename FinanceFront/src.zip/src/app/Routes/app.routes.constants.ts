export const buildRoute = (...segments: string[]) => segments.filter(Boolean).join('/');

export const AppRoutes = {
  Login: 'login',
  ForgotPassword: 'forgot-password',
  ResetPassword: 'reset-password',
  AdminRoot: 'admin',
  ClientRoot: 'client',
  Dashboard: 'dashboard',
  Finance: 'finance',
  Account: 'account',
  Profile: 'profile',
  Security: 'security',
  Users: 'users',
  Add: 'add',
  Edit: 'edit',
  Detail: 'detail',
  Compare: 'compare',
  Menu: 'menu',
  Notifications: 'notifications',
  Watchlist: 'watchlist',
  Portfolio: 'portfolio',
  Analysis: 'analysis',
  History: 'history',
  Simulation: 'simulation',
  Instruments: 'instruments',
  InstrumentRegistry: 'instrument-registry',
  PeaRegistry: 'pea-registry',
  ScoringPolicy: 'scoring-policy',
  ParameterDictionary: 'parameter-dictionary',
  WordingVersions: 'wording-versions',
  SnapshotAudit: 'snapshot-audit',
  DataQuality: 'data-quality'
} as const;

export const AuthPaths = {
  Login: AppRoutes.Login,
  ForgotPassword: AppRoutes.ForgotPassword,
  ResetPassword: AppRoutes.ResetPassword
} as const;

export const AdminPaths = {
  Dashboard: buildRoute(AppRoutes.AdminRoot, AppRoutes.Dashboard),
  UsersList: buildRoute(AppRoutes.AdminRoot, AppRoutes.Users),
  UserAdd: buildRoute(AppRoutes.AdminRoot, AppRoutes.Users, AppRoutes.Add),
  UserEdit: (id: string) => buildRoute(AppRoutes.AdminRoot, AppRoutes.Users, AppRoutes.Edit, id),
  InstrumentRegistry: buildRoute(AppRoutes.AdminRoot, AppRoutes.InstrumentRegistry),
  PeaRegistry: buildRoute(AppRoutes.AdminRoot, AppRoutes.PeaRegistry),
  ScoringPolicy: buildRoute(AppRoutes.AdminRoot, AppRoutes.ScoringPolicy),
  ParameterDictionary: buildRoute(AppRoutes.AdminRoot, AppRoutes.ParameterDictionary),
  ParameterDictionaryDetail: (parameterId: string) => buildRoute(AppRoutes.AdminRoot, AppRoutes.ParameterDictionary, AppRoutes.Detail, parameterId),
  WordingVersions: buildRoute(AppRoutes.AdminRoot, AppRoutes.WordingVersions),
  WordingVersionsDetail: (wordingVersionId: string) => buildRoute(AppRoutes.AdminRoot, AppRoutes.WordingVersions, AppRoutes.Detail, wordingVersionId),
  SnapshotAudit: buildRoute(AppRoutes.AdminRoot, AppRoutes.SnapshotAudit),
  SnapshotAuditDetail: (analysisRunId: string) => buildRoute(AppRoutes.AdminRoot, AppRoutes.SnapshotAudit, AppRoutes.Detail, analysisRunId),
  SnapshotAuditCompare: buildRoute(AppRoutes.AdminRoot, AppRoutes.SnapshotAudit, AppRoutes.Compare),
  DataQuality: buildRoute(AppRoutes.AdminRoot, AppRoutes.DataQuality)
} as const;

export const UserPaths = {
  Dashboard: buildRoute(AppRoutes.ClientRoot, AppRoutes.Dashboard),
  Finance: buildRoute(AppRoutes.ClientRoot, AppRoutes.Finance),
  Notifications: buildRoute(AppRoutes.ClientRoot, AppRoutes.Notifications),
  Watchlist: buildRoute(AppRoutes.ClientRoot, AppRoutes.Watchlist),
  Portfolio: buildRoute(AppRoutes.ClientRoot, AppRoutes.Portfolio),
  AnalysisEntry: buildRoute(AppRoutes.ClientRoot, AppRoutes.Analysis),
  AnalysisDetail: (analysisId: string) => buildRoute(AppRoutes.ClientRoot, AppRoutes.Analysis, analysisId),
  History: buildRoute(AppRoutes.ClientRoot, AppRoutes.History),
  Simulation: buildRoute(AppRoutes.ClientRoot, AppRoutes.Simulation),
  InstrumentDetail: (symbol: string) => buildRoute(AppRoutes.ClientRoot, AppRoutes.Instruments, symbol),
  Account: buildRoute(AppRoutes.ClientRoot, AppRoutes.Account),
  Profile: buildRoute(AppRoutes.ClientRoot, AppRoutes.Account, AppRoutes.Profile),
  Security: buildRoute(AppRoutes.ClientRoot, AppRoutes.Account, AppRoutes.Security)
} as const;

export const AppAreas = {
  Admin: AppRoutes.AdminRoot,
  User: AppRoutes.ClientRoot,
} as const;
