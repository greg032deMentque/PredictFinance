import { Routes } from '@angular/router';
import { LoginComponent } from '../components/login/login';
import { ForgotPasswordComponent } from '../components/auth/forgot-password/forgot-password.component';
import { ResetPasswordComponent } from '../components/auth/reset-password/reset-password.component';
import { AppRoutes } from './app.routes.constants';

export const AUTH_ROUTES: Routes = [
  {
    path: AppRoutes.Login,
    component: LoginComponent,
    data: { publicShell: true }
  },
  {
    path: AppRoutes.ForgotPassword,
    component: ForgotPasswordComponent,
    data: { publicShell: true }
  },
  {
    path: AppRoutes.ResetPassword,
    component: ResetPasswordComponent,
    data: { publicShell: true }
  },
  { path: '', pathMatch: 'full', redirectTo: AppRoutes.Login }
];
